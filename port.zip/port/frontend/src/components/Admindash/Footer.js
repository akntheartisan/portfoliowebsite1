import React from 'react'
import "../../Admin.css";

const Footer = () => {
  return (
    
        <footer className='adminfooter'>
            <h3>Desgined By Arvind Nagaraj</h3>
        </footer>
    
  )
}

export default Footer