import React from 'react'

const Form = () => {
  return (
    <div>
        <h2>form</h2>
    </div>
  )
}

export default Form