import React from 'react'

const Table = () => {
  return (
    <div>
        <h1>table</h1>
    </div>
  )
}

export default Table