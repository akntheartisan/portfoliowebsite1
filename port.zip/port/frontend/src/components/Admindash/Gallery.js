import React from 'react'

const Gallery = () => {
  return (
    <div>
        <h1>
            gallery
        </h1>
        </div>
  )
}

export default Gallery